1. 
	Items(ItemID, Name, First_Bid, Started, Ends, Description) key: ItemID
	ItemCategory(ItemID, Category) key:ItemID
	ItemPrice(ItemID, Buy_Price) key:ItemID
	ItemLocation(ItemID, Location, Latitude, Longitude, Country) key: ItemID
	Bids(ItemId, UserID, Time, Amount) key: ItemID, UserID, Time
	Seller(UserID, Rating) key: UserID
	Bidder(UserID, Location, Country, Rating) key: UserID

2. 
	All our nontrivial functional dependencies specify keys.

3.
	Yes, they are all in Boyce-Codd Normal Form.

4. 
	Yes, they are all in Fourth Normal Form.