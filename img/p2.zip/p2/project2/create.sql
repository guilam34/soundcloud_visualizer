CREATE TABLE Items (
	ItemID int PRIMARY KEY,
	Name varchar(100),
	First_Bid int,
	Started timestamp,
	Ends timestamp,
	Description varchar(4000)
);

CREATE TABLE ItemCategory (
	ItemID int,
	Category varchar(100),
	PRIMARY KEY(ItemID, Category)
);

CREATE TABLE ItemPrice (
	ItemID int PRIMARY KEY,
	Buy_Price decimal(8, 2)
);

CREATE TABLE ItemLocation (
	ItemID int PRIMARY KEY,
	Location varchar(100),
	Latitude decimal(8, 6) default NULL,
	Longitude decimal(9, 6) default NULL,
	Country varchar(100)
);

CREATE TABLE Bids (
	ItemID int,
	UserID varchar(100),
	Time timestamp,
	Amount decimal(8, 2),
	PRIMARY KEY(ItemID, UserID, Time)
);

CREATE TABLE Seller (
	UserID varchar(100) PRIMARY KEY,
	Rating int
);

CREATE TABLE Bidder (
	UserID varchar(100) PRIMARY KEY,
	Location varchar(100) default NULL,
	Country varchar(100) default NULL,
	Rating int
);