#!/bin/sh

# Run the drop.sql batch file to drop existing tables
# Inside the drop.sql, you sould check whether the table exists. Drop them ONLY if they exists.
mysql CS144 < drop.sql

# Run the create.sql batch file to create the database and tables
mysql CS144 < create.sql

# Compile and run the parser to generate the appropriate load files
ant
ant run-all

# If the Java code does not handle duplicate removal, do this now
uniq items.csv > temp.csv
cat temp.csv > items.csv
uniq item-category.csv > temp.csv
cat temp.csv > item-category.csv
uniq item-price.csv > temp.csv
cat temp.csv > item-price.csv
uniq item-location.csv > temp.csv
cat temp.csv > item-location.csv
uniq bids.csv > temp.csv
cat temp.csv > bids.csv
uniq seller.csv > temp.csv
cat temp.csv > seller.csv
uniq bidder.csv > temp.csv
cat temp.csv > bidder.csv
rm temp.csv

# Run the load.sql batch file to load the data
mysql CS144 < load.sql

# Remove all temporary files
rm items.csv item-category.csv item-price.csv item-location.csv bids.csv seller.csv bidder.csv